import os, json, argparse
from pathlib import Path
import cv2
import yolov5

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--input_dir',  required=True)
    p.add_argument('--output_dir', required=True)
    args = p.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    model = yolov5.load('yolov5s')

    output = {}
    for img_path in Path(args.input_dir).glob('*.jpg'):
        img = cv2.imread(str(img_path))
        results = model(img)
        dets = []
        for *box, conf, cls in results.pred[0].cpu().numpy():
            x1,y1,x2,y2 = map(float, box)
            dets.append({
                'class': model.names[int(cls)],
                'bbox': [x1,y1,x2,y2],
                'confidence': float(conf)
            })
        output[img_path.name] = {'detections': dets}
        annotated = results.render()[0]
        cv2.imwrite(os.path.join(args.output_dir, f'annotated_{img_path.name}'), annotated)

    with open(os.path.join(args.output_dir, 'detections.json'), 'w') as f:
        json.dump(output, f, indent=2)

if __name__=='__main__':
    main()
