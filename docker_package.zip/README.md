# Dockerized Object Detection

## Build
\`\`\`bash
docker build -t object-detection .
\`\`\`

## Run
\`\`\`bash
mkdir input output
# put .jpg images into ./input
docker run -v $(pwd)/input:/input -v $(pwd)/output:/output object-detection
\`\`\`

Outputs (annotated images + detections.json) appear in ./output
